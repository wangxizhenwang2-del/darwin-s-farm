using System.Collections.Generic;
using UnityEngine;

public class MapGridManager : MonoBehaviour
{
    public const float TileSize = 17f;
    public const float CoreSize = 15f;

    public event System.Action TilesChanged;

    public RuntimeMapNavigation Navigation => mapNavigation;

    [ContextMenu("Population Debug/Create two on test coordinate (Play Mode)")]
    private void TestCreatePopulations()
    {
        PopulationMovementController controller = PopulationMovementController.GetOrCreate(this);
        if (controller != null) controller.CreateDebugPopulations(testCoordinate);
    }

    public const float HeightStep = 1f;

    private static readonly Vector2Int[] Directions =
    {
        Vector2Int.right,
        Vector2Int.left,
        Vector2Int.up,
        Vector2Int.down
    };

    [Header("��������")]
    [SerializeField] private Transform placedTiles;
    [SerializeField] private RuntimeMapNavigation mapNavigation;
    [SerializeField] private Material tileMaterial;

    [Header("�ؿ�����")]
    [SerializeField] private MapTileDefinition initialTile;

    [Header("����ʱ���ò���")]
    [SerializeField] private MapTileDefinition testTile;
    [SerializeField]
    private Vector2Int testCoordinate =
        new Vector2Int(1, 0);

    [Header("Scene���ڸ�����ʾ")]
    [SerializeField] private bool showAvailablePositions = true;

    private readonly Dictionary<Vector2Int, MapTileInstance> tiles =
    new Dictionary<Vector2Int, MapTileInstance>();

    private int groundLayer;
    private bool initialized;

    private void Start()
    {
        groundLayer = LayerMask.NameToLayer("Ground");

        if (placedTiles == null ||
            mapNavigation == null ||
            tileMaterial == null ||
            initialTile == null ||
            groundLayer < 0)
        {
            Debug.LogError(
                "��ͼ���ò���������û����ΪGround��Layer��",
                this);

            enabled = false;
            return;
        }

        initialized = true;

        TryPlaceTile(Vector2Int.zero, initialTile);
    }

    public IEnumerable<MapTileInstance> GetPlacedTiles()
    {
        return tiles.Values;
    }

    // ��������ת��������λ�á�
    public Vector3 GridToWorld(Vector2Int coordinate)
    {
        return placedTiles.position + new Vector3(
            coordinate.x * TileSize,
            0f,
            coordinate.y * TileSize);
    }

    // ����λ��ת����������������ꡣ
    public Vector2Int WorldToGrid(Vector3 worldPosition)
    {
        Vector3 offset = worldPosition - placedTiles.position;

        return new Vector2Int(
            Mathf.RoundToInt(offset.x / TileSize),
            Mathf.RoundToInt(offset.z / TileSize));
    }

    public bool CanPlaceAt(Vector2Int coordinate)
    {
        if (!initialized || tiles.ContainsKey(coordinate))
            return false;

        // ��һ��ֻ��������ԭ�㡣
        if (tiles.Count == 0)
            return coordinate == Vector2Int.zero;

        // ֻ����������ң������Խǡ�
        foreach (Vector2Int direction in Directions)
        {
            if (tiles.ContainsKey(coordinate + direction))
                return true;
        }

        return false;
    }

    public bool TryPlaceTile(
    Vector2Int coordinate,
    MapTileDefinition definition,
    int rotationSteps = 0)
    {
        if (definition == null || !CanPlaceAt(coordinate))
            return false;

        GameObject tileRoot = new GameObject(
            $"Tile_{coordinate.x}_{coordinate.y}_{definition.displayName}");

        tileRoot.transform.SetParent(placedTiles, false);
        tileRoot.transform.position =
    GridToWorld(coordinate) +
    Vector3.up * definition.heightLevel * HeightStep;

        rotationSteps = ((rotationSteps % 4) + 4) % 4;

        tileRoot.transform.rotation =
            Quaternion.Euler(0f, rotationSteps * 90f, 0f);

        Color coreColor = definition.mainColor;

        // ��ʱ�ý�����ɫ������Χ����
        Color borderColor = new Color(
            coreColor.r * 0.75f,
            coreColor.g * 0.75f,
            coreColor.b * 0.75f,
            1f);

        // ���壺15��15�ס�
        CreatePart(
            tileRoot.transform,
            "Core",
            new Vector3(0f, -0.25f, 0f),
            new Vector3(15f, 0.5f, 15f),
            coreColor);

        // ǰ�����������Ľǣ�����Ϊ17�ס�
        CreatePart(
            tileRoot.transform,
            "Border_North",
            new Vector3(0f, -0.25f, 8f),
            new Vector3(17f, 0.5f, 1f),
            borderColor);

        CreatePart(
            tileRoot.transform,
            "Border_South",
            new Vector3(0f, -0.25f, -8f),
            new Vector3(17f, 0.5f, 1f),
            borderColor);

        // ������������Ϊ15�ף������ظ������Ľǡ�
        CreatePart(
            tileRoot.transform,
            "Border_East",
            new Vector3(8f, -0.25f, 0f),
            new Vector3(1f, 0.5f, 15f),
            borderColor);

        CreatePart(
            tileRoot.transform,
            "Border_West",
            new Vector3(-8f, -0.25f, 0f),
            new Vector3(1f, 0.5f, 15f),
            borderColor);

        CreatePart(
     tileRoot.transform,
     "DirectionMarker",
     new Vector3(0f, 0.12f, 4f),
     new Vector3(0.5f, 0.24f, 3f),
     Color.white);

        // ���ֻ��ʾ���򣬲�������ײ��
        Collider markerCollider = tileRoot.transform
            .Find("DirectionMarker")
            .GetComponent<Collider>();

        markerCollider.enabled = false;
        Destroy(markerCollider);

        MapTileInstance instance =
     tileRoot.AddComponent<MapTileInstance>();

        // ��ʱ������ı߶��Ѿ�������ɡ�
        instance.Initialize(
     coordinate,
     definition,
     definition.heightLevel,
     rotationSteps);

        tiles.Add(coordinate, instance);

        // �������µĿɼ��������ײ�塣
        TilesChanged?.Invoke();

        // �����󵼺����¡�
        mapNavigation.RequestUpdate();

        return true;
    }

    // Low-level map mutations are invoked by the paid player operation controller.
    public bool TryRemoveTile(Vector2Int coordinate)
    {
        if (!initialized || coordinate == Vector2Int.zero ||
            !tiles.TryGetValue(coordinate, out MapTileInstance tile)) return false;
        tiles.Remove(coordinate);
        tile.gameObject.SetActive(false);
        Destroy(tile.gameObject);
        TilesChanged?.Invoke();
        mapNavigation.RequestUpdate();
        return true;
    }

    public bool TryChangeWaterShape(Vector2Int coordinate, MapTileDefinition definition,
        int rotationSteps)
    {
        if (!initialized || definition == null ||
            definition.initialWaterCoverage == WaterCoverage.Land ||
            !tiles.TryGetValue(coordinate, out MapTileInstance tile) ||
            tile.Block == null || tile.Block.waterCoverage == WaterCoverage.Land ||
            (tile.Definition == definition &&
             WaterBodyTopology.OpeningMask(tile.Definition, tile.RotationSteps) ==
             WaterBodyTopology.OpeningMask(definition, rotationSteps)))
            return false;
        tile.SetWaterShape(definition, rotationSteps);
        TilesChanged?.Invoke();
        mapNavigation.RequestUpdate();
        return true;
    }

    // The future player operation layer validates cost and permission before calling this.
    public bool TrySetTileHeight(Vector2Int coordinate, int level)
    {
        if (!initialized || level < 0 || level > 2 ||
            !tiles.TryGetValue(coordinate, out MapTileInstance tile) ||
            tile.HeightLevel == level)
            return false;

        tile.SetHeightLevel(level, GridToWorld(coordinate));
        TilesChanged?.Invoke();
        mapNavigation.RequestUpdate();
        return true;
    }

    // 2026-10-09 14:27 +08:00: a water-body height operation validates every
    // member first, then raises one graph event after the complete map commit.
    public bool TryShiftTileHeights(IReadOnlyList<Vector2Int> coordinates, int delta)
    {
        if (!initialized || coordinates == null || coordinates.Count == 0 ||
            (delta != -1 && delta != 1)) return false;
        var members = new List<MapTileInstance>(coordinates.Count);
        var seen = new HashSet<Vector2Int>();
        foreach (Vector2Int coordinate in coordinates)
        {
            if (!seen.Add(coordinate) || !tiles.TryGetValue(coordinate, out MapTileInstance tile) ||
                tile.HeightLevel + delta < 0 || tile.HeightLevel + delta > 2)
                return false;
            members.Add(tile);
        }
        foreach (MapTileInstance tile in members)
            tile.SetHeightLevel(tile.HeightLevel + delta, GridToWorld(tile.Coordinate));
        TilesChanged?.Invoke();
        mapNavigation.RequestUpdate();
        return true;
    }
    private void CreatePart(
        Transform parent,
        string partName,
        Vector3 localPosition,
        Vector3 localScale,
        Color color)
    {
        GameObject part =
            GameObject.CreatePrimitive(PrimitiveType.Cube);

        part.name = partName;
        part.layer = groundLayer;

        part.transform.SetParent(parent, false);
        part.transform.localPosition = localPosition;
        part.transform.localScale = localScale;

        Renderer partRenderer = part.GetComponent<Renderer>();
        partRenderer.sharedMaterial = tileMaterial;

        MaterialPropertyBlock properties =
            new MaterialPropertyBlock();

        // ����URP Lit��Built-in Standard����ɫ���ԡ�
        properties.SetColor("_BaseColor", color);
        properties.SetColor("_Color", color);

        partRenderer.SetPropertyBlock(properties);
    }

    public HashSet<Vector2Int> GetAvailablePositions()
    {
        HashSet<Vector2Int> positions =
            new HashSet<Vector2Int>();

        foreach (Vector2Int coordinate in tiles.Keys)
        {
            foreach (Vector2Int direction in Directions)
            {
                Vector2Int candidate = coordinate + direction;

                if (!tiles.ContainsKey(candidate))
                    positions.Add(candidate);
            }
        }

        return positions;
    }

    [ContextMenu("���Է��õؿ飨����ʱ��")]
    private void TestPlaceTile()
    {
        if (!Application.isPlaying || !initialized)
        {
            Debug.LogWarning("���ڵ�ͼ��ʼ���������ģʽ�²��ԡ�", this);
            return;
        }

        bool success = TryPlaceTile(testCoordinate, testTile);

        Debug.Log(
            success
                ? $"���óɹ���{testCoordinate}"
                : $"����ʧ�ܣ�{testCoordinate}��������û�λ���Ƿ�Ϸ���",
            this);
    }

    private void OnDrawGizmos()
    {
        if (!Application.isPlaying ||
            !initialized ||
            !showAvailablePositions)
        {
            return;
        }

        Gizmos.color = Color.cyan;

        foreach (Vector2Int coordinate in GetAvailablePositions())
        {
            Gizmos.DrawWireCube(
                GridToWorld(coordinate) + Vector3.up * 0.05f,
                new Vector3(TileSize, 0.02f, TileSize));
        }
    }

    public bool TryGetTile(
    Vector2Int coordinate,
    out MapTileInstance tile)
    {
        return tiles.TryGetValue(coordinate, out tile);
    }

    public bool TryGetNeighbor(
        Vector2Int coordinate,
        Vector2Int direction,
        out MapTileInstance neighbor)
    {
        neighbor = null;

        // ֻ���������������ַ���
        if (direction != Vector2Int.up &&
            direction != Vector2Int.down &&
            direction != Vector2Int.left &&
            direction != Vector2Int.right)
        {
            return false;
        }

        return tiles.TryGetValue(
            coordinate + direction,
            out neighbor);
    }

    [ContextMenu("������������ھӣ�����ʱ��")]
    private void CheckTestNeighbors()
    {
        if (!Application.isPlaying || !initialized)
        {
            Debug.LogWarning("���ڵ�ͼ��ʼ���������ģʽ�¼�顣", this);
            return;
        }

        if (!TryGetTile(testCoordinate, out MapTileInstance tile))
        {
            Debug.Log($"λ��{testCoordinate}û���ѷ��õؿ顣", this);
            return;
        }

        Debug.Log(
            $"���ؿ飺{tile.Coordinate}��" +
            $"Biome��{tile.Biome}��" +
            $"�߶ȣ�{tile.HeightLevel}",
            tile);

        foreach (Vector2Int direction in Directions)
        {
            string directionName =
                direction == Vector2Int.up ? "��" :
                direction == Vector2Int.down ? "��" :
                direction == Vector2Int.left ? "��" : "��";

            if (TryGetNeighbor(
                    testCoordinate,
                    direction,
                    out MapTileInstance neighbor))
            {
                Debug.Log(
                    $"{directionName}���ھӣ�{neighbor.Coordinate}��" +
                    $"Biome��{neighbor.Biome}��" +
                    $"�߶ȣ�{neighbor.HeightLevel}",
                    neighbor);
            }
            else
            {
                Debug.Log($"{directionName}��û���ھӡ�", tile);
            }
        }
    }
}