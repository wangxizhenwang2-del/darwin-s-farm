using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TilePaletteUI : MonoBehaviour
{
    [Header("UI����")]
    [SerializeField] private RectTransform content;
    [SerializeField] private TilePaletteItemUI itemPrefab;
    [SerializeField] private ScrollRect scrollRect;

    [Header("��ק����")]
    [SerializeField]
    private MapTilePlacementController placementController;

    [Header("��ѡ��ĵؿ�")]
    [SerializeField] private MapTileDefinition[] definitions;

    public IReadOnlyList<MapTileDefinition> Definitions => definitions;

    private void Start()
    {
        if (content == null ||
            itemPrefab == null ||
            scrollRect == null ||
            placementController == null)
        {
            Debug.LogError("�ؿ��б���UI����ק����δ���á�", this);
            return;
        }

        if (definitions != null)
        {
            foreach (MapTileDefinition definition in definitions)
            {
                if (definition == null)
                    continue;

                TilePaletteItemUI item =
                    Instantiate(itemPrefab, content);

                item.Bind(definition, placementController);
            }
        }

        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(content);

        scrollRect.StopMovement();
        scrollRect.horizontalNormalizedPosition = 0f;
    }
}