using UnityEngine;
using UnityEngine.Rendering;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public class MapBuildModeController : MonoBehaviour
{
    [Header("��ͼ��Ԥ��")]
    [SerializeField] private MapGridManager gridManager;
    [SerializeField] private Transform previewRoot;
    [SerializeField] private Material previewMaterial;

    [Header("����UI")]
    [SerializeField] private GameObject buildPanel;

    [Header("��Һ����")]
    [SerializeField] private ClickToMove clickToMove;
    [SerializeField] private ScreenEdgeCamera screenEdgeCamera;

    [Header("�߿�����")]
    [SerializeField, Min(0.01f)]
    private float lineWidth = 0.12f;

    [SerializeField, Min(0.01f)]
    private float heightOffset = 0.08f;

    private float previewHeight;

    public bool IsBuildMode { get; private set; }

    private void Awake()
    {
        if (gridManager == null ||
            previewRoot == null ||
            previewMaterial == null ||
            buildPanel == null)
        {
            Debug.LogError("����ģʽ�ĵ�ͼ��Ԥ����UI����δ���á�", this);

            enabled = false;
        }
    }

    private void OnEnable()
    {
        if (gridManager != null)
            gridManager.TilesChanged += HandleTilesChanged;
    }

    private void Start()
    {
        // Ĭ�Ϲرս���ģʽ��
        SetBuildMode(false);
    }

    private void Update()
    {
        if (!Application.isFocused || ScreenEdgeCamera.IsTextInputFocused())
            return;

        bool pressedN;

#if ENABLE_INPUT_SYSTEM
        pressedN = Keyboard.current != null &&
                   Keyboard.current.nKey.wasPressedThisFrame;
#else
        pressedN = Input.GetKeyDown(KeyCode.N);
#endif

        if (pressedN)
            SetBuildMode(!IsBuildMode);
    }

    public void SetBuildMode(bool value)
    {
        IsBuildMode = value;

        if (buildPanel != null)
            buildPanel.SetActive(value);

        if (previewRoot != null)
            previewRoot.gameObject.SetActive(value);

        // ����ģʽ�У��������µĵ���ƶ�ָ�
        if (clickToMove != null)
            clickToMove.SetMovementInputEnabled(!value);

        // �л�������룬��ǰ�ӽǱ��ֲ��䡣
        if (screenEdgeCamera != null)
            screenEdgeCamera.SetBuildMode(value);

        if (value)
            RefreshPreview();
    }

    private void HandleTilesChanged()
    {
        if (IsBuildMode)
            RefreshPreview();
    }

    private void RefreshPreview()
    {
        if (gridManager == null ||
            previewRoot == null ||
            previewMaterial == null)
        {
            return;
        }

        ClearPreview();

        foreach (Vector2Int coordinate
                 in gridManager.GetAvailablePositions())
        {
            CreateOutline(coordinate);
        }
    }

    private void CreateOutline(Vector2Int coordinate)
    {
        GameObject outline = new GameObject(
            $"BuildOutline_{coordinate.x}_{coordinate.y}");

        outline.transform.SetParent(previewRoot, false);

        LineRenderer line = outline.AddComponent<LineRenderer>();

        line.sharedMaterial = previewMaterial;
        line.useWorldSpace = true;
        line.loop = true;
        line.positionCount = 4;

        line.startColor = Color.white;
        line.endColor = Color.white;

        line.startWidth = lineWidth;
        line.endWidth = lineWidth;

        line.numCornerVertices = 3;

        line.shadowCastingMode = ShadowCastingMode.Off;
        line.receiveShadows = false;

        float halfSize = MapGridManager.TileSize * 0.5f;

        Vector3 center = gridManager.GridToWorld(coordinate);
        center.y += heightOffset + previewHeight;

        line.SetPositions(new Vector3[]
        {
            center + new Vector3(-halfSize, 0f, -halfSize),
            center + new Vector3(-halfSize, 0f,  halfSize),
            center + new Vector3( halfSize, 0f,  halfSize),
            center + new Vector3( halfSize, 0f, -halfSize)
        });
    }

    private void ClearPreview()
    {
        for (int i = previewRoot.childCount - 1; i >= 0; i--)
        {
            GameObject child = previewRoot.GetChild(i).gameObject;

            // Destroy����֡ĩִ�У������ر�������ص���
            child.SetActive(false);
            Destroy(child);
        }
    }

    private void OnDisable()
    {
        if (gridManager != null)
            gridManager.TilesChanged -= HandleTilesChanged;

        SetBuildMode(false);
    }

    public void SetPreviewHeight(float height)
    {
        if (Mathf.Approximately(previewHeight, height))
            return;

        previewHeight = height;

        if (IsBuildMode)
            RefreshPreview();
    }
}